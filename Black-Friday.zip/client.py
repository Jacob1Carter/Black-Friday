from tools import backup_project


def main(username, ip, port):
    pass


if __name__ == "__main__":
    backup_project()
    main()
